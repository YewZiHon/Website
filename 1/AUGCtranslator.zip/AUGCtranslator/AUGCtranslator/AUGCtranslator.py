import tkinter as tk
from tkinter import filedialog
import sys
import time
import datetime

data=[]
#kinematics tracking
minX=-1
minY=-1
maxX=-1
maxY=-1
layercount=-1
x=0
y=0
lastx=0
lasty=0
exceedlim=False

#ask user to select file and get file name and path.
root=tk.Tk()
root.withdraw()
filepath=filedialog.askopenfilename()
#print(filepath)
filename=filepath[filepath.rfind("/")+1:]#find last file delimiter
#print("Selected:",filename)
newfilename=filename[:filename.find(".")]+".augc"
newfilename=filepath[:filepath.rfind("/")+1]+newfilename
#print(newfilename)

#check file name is valid
if filename.rfind(".gcode")==-1:
    print("Invalid file name")
    time.sleep(1000)
    
else:#read file and translate
    now = datetime.datetime.now()
    year=int(str(now.year)[-2:])
    list(data)
    data=[0x2e,0x61,0x75,0x67, 0x63,0x00,0x59,0x65, 0x77,0x20,0x5a,0x69, 0x20,0x48,0x6f,0x6e, 0x01,now.hour,now.minute,now.second, now.day,now.month,year,0x00, 0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00]
    
    f = open(filepath, "r")
    line=" "
    #index=32
    while line!="":
        line=f.readline()
        if line.find(";")==0:#check for comment
            if line.find(";MINX:")==0:
                minX=float(line[6:])
                #print("minX=",minX)
            elif line.find(";MINY:")==0:
                minY=float(line[6:])
                #print("minY=",minY)
            elif line.find(";MAXX:")==0:
                maxX=float(line[6:])
                #print("maxX=",maxX)
            elif line.find(";MAXY:")==0:
                maxY=float(line[6:])
                #print("maxY=",maxY)
            elif line.find(";LAYER_COUNT:")==0:
                layercount=int(line[13:])
                #print("Layer count=",layercount)
        elif line.find("G0")==0:#look for rapid moves
            if line.find("X")!=-1:
                x=round(float(line[line.find("X")+1:line.find(" ",line.find("X"))]),2)
                #print(x)
                x1=int(x)
                x2=round((x-x1)*100)
                data.append(x1)
                data.append(x2)
                if x<0 or x>127.99:
                    print("exceeded limits")
                    exceedlim=True
            if line.find("Y")!=-1:
                y=round(float(line[line.find("Y")+1:line.find(" ",line.find("Y"))]),2)
                #print(y)
                y1=int(y)
                y2=round((y-y1)*100)
                data.append(y1)
                data.append(y2)
                if y<0 or y>189.99:
                    print("exceeded limits")
                    exceedlim=True
        elif line.find("G1")==0:#look for plotting moves
            if line.find("X")!=-1:
                x=round(float(line[line.find("X")+1:line.find(" ",line.find("X"))]),2)
                #print(x)
                x1=int(x)+128
                x2=round((x-int(x))*100)
                data.append(x1)
                data.append(x2)
                if x<0 or x>127.99:
                    print("exceeded limits")
                    exceedlim=True
            if line.find("Y")!=-1:
                y=round(float(line[line.find("Y")+1:line.find(" ",line.find("Y"))]),2)
                #print(y)
                y1=int(y)
                y2=round((y-y1)*100)
                data.append(y1)
                data.append(y2)
                if y<0 or y>189.99:
                    print("exceeded limits")
                    exceedlim=True


        #print(line)
    f.close()
    if minX==-1 or minY==-1 or maxX==-1 or maxY==-1:
        print("Limits unknown proceed with caution")
#C:/Users/Zi Hon/OneDrive - Singapore Polytechnic/Desktop/NULL/1000/Alpha/test.gcode
#finding the date
now = datetime.datetime.now()
year=int(str(now.year)[-2:])
layercounth=int(layercount/256)
layercountl=int(layercount%256)
#data=[0x2e,0x61,0x75,0x67, 0x63,0x00,0x59,0x65, 0x77,0x20,0x5a,0x69, 0x20,0x48,0x6f,0x6e, 0x01,now.second,now.minute,now.hour, now.day,now.month,year,layercounth, layercountl,0x00,0x00,0x00, 0x00,0x00,0x00,0x00]
print(data) 
f = open(newfilename, 'wb') 
arr=bytearray(data)
f.write(arr)
f.close()